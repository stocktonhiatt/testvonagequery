import React from 'react';
import '../css/Loading.css';

const Loading = () => <div className="loading"></div>;

export default Loading;
