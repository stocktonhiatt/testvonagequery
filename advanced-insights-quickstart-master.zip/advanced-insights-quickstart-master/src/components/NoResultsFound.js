import React from 'react';

const NoResultsFound = () => <div>No results found.</div>;

export default NoResultsFound;
